package dto;

public class AdminRequest {

	private String admin_ID;
	private String admin_Name;
	private String admin_password;
	public String getAdmin_ID() {
		return admin_ID;
	}
	public void setAdmin_ID(String admin_ID) {
		this.admin_ID = admin_ID;
	}
	public String getAdmin_Name() {
		return admin_Name;
	}
	public void setAdmin_Name(String admin_Name) {
		this.admin_Name = admin_Name;
	}
	public String getAdmin_password() {
		return admin_password;
	}
	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}
	@Override
	public String toString() {
		return "AdminRequest [admin_ID=" + admin_ID + ", admin_Name=" + admin_Name + ", admin_password="
				+ admin_password + "]";
	}
	
	
}
