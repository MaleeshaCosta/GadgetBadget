package dto;

public class AdminResponse {

	private String admin_id;
	private String message;
	public String getAdmin_id() {
		return admin_id;
	}
	public void setAdmin_id(String string) {
		this.admin_id = string;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	
	
}
