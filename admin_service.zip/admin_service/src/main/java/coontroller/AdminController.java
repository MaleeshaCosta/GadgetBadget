package coontroller;

import java.util.UUID;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import dto.AdminRequest;
import dto.AdminResponse;



@RestController
@RequestMapping("/admin")
public class AdminController {

	@PostMapping(consumes="application/json",produces="application/json")
	public @ResponseBody AdminResponse createAdmin(@RequestBody AdminRequest request ) {
		
		System.out.println("admin details:" + request);
		
		var AdminResponse = new AdminResponse();
		AdminResponse.setAdmin_id(UUID.randomUUID().toString());
		AdminResponse.setMessage("Successfully created the profile");
		return AdminResponse;
	}
}